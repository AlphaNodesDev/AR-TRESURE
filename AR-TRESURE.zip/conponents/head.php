<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>AR TREASURE</title>
    <link rel="stylesheet" type="text/css" href="./assets/css/login-register.css?<?php echo filemtime('./assets/css/login-register.css'); ?>">

    <link rel="stylesheet" href="https://fonts.googleapis.com/css2?family=Material+Symbols+Outlined:opsz,wght,FILL,GRAD@20..48,100..700,0..1,-50..200" />
</head>